import React from 'react';
class Menu extends React.Component{
    render() {
        return (
            <div className='Menu'>
                <ul className='lista'>
                    <li>Home</li>
                    <li>Products</li>
                    <li>Contact Us</li>
                </ul>
            </div>
            );
    }
}
export default Menu;
